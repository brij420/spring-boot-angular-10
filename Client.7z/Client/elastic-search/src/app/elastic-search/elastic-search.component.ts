import { Component, OnInit } from '@angular/core';
import { SearchService } from 'src/app/services/search.service';

@Component({
  selector: 'app-elastic-search',
  templateUrl: './elastic-search.component.html',
  styleUrls: ['./elastic-search.component.css']
})
export class ElasticSearchComponent implements OnInit {

  search:any = '';
  result:Array<any>=[];

  constructor(private searchService: SearchService) { 
   // this.search = 'elastic-search';
  }

  ngOnInit(): void {
  }

  getSearchResult(): void {  

    this.searchService.getSearchResult(this.search)
      .subscribe(
        response => {
          console.log(response);
          this.result = response;
        },
        error => {
          console.log(error);
        });
  }

}
