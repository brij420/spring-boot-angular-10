package com.search.elasticsearch.dao;

import java.util.List;

import com.search.elasticsearch.model.Data;

public interface MyEntityRepository { 

    public List<Data> getAllSearchResult(String search);


}