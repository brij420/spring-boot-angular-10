package com.search.elasticsearch.daoimpl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Component;

import com.search.elasticsearch.dao.MyEntityRepository;
import com.search.elasticsearch.model.Data;

@Component 
public class MyEntityRepositoryImpl implements MyEntityRepository{ 

    @PersistenceContext
    private EntityManager entityManager;


    @SuppressWarnings("unused")
    public List<Data> getAllSearchResult(String text){
        String sql = "SELECT e FROM Data e WHERE lower(e.text) LIKE lower(concat(:text, '%'))";
        TypedQuery<Data> query = entityManager.createQuery(sql, Data.class);
        query.setParameter("text", text);
        return query.getResultList();
    }


}