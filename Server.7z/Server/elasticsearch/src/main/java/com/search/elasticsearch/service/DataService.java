package com.search.elasticsearch.service;

import java.util.List;

import com.search.elasticsearch.model.Data;

public interface DataService {
	List<Data> getAllSearchResult(String search);
}
