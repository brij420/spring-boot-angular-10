package com.search.elasticsearch.serviceimpl;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.search.elasticsearch.dao.MyEntityRepository;
import com.search.elasticsearch.model.Data;
import com.search.elasticsearch.repository.DataRepository;
import com.search.elasticsearch.service.DataService;

/**
 * @author Brijesh Kumar
 *
 */
@Service
@Transactional
public class DataServiceImpl implements DataService {
	@Autowired
	private DataRepository dataRepository;
	
	@Autowired
	private MyEntityRepository myEntityRepository;

	@Override
	public List<Data> getAllSearchResult(String search) {
		//return dataRepository.findAll();
		
		return myEntityRepository.getAllSearchResult(search);
	}

}
